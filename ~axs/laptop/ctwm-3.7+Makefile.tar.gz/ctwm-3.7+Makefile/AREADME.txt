AREADME.txt
20 Aug 2006

READ THIS BEFORE README

The files in here all come from the ctwm-3.7.tar.gz tar ball downloaded
from the ctwm web site in July 2005

    http://ctwm.free.lp.se/dist

(As far as I know that is the latest version of ctwm, but
I cannot check as that web site seems to be temporarily
unavailable.)

When I upgraded my laptop to Fedora Core 5, I could no longer
compile ctwm because the command 'xmkmf' no longer works.

So I did the following on a system running FC 4:

    cp -p Imakefile.local-template Imakefile.local

I left all the defaults in Imakefile.local unchanged

    xmkmf

That created Makefile

I then copied the whole directory to my FC5 laptop and ran 'make'
followed by 'make install'

Since then ctwm has been working perfectly on that machine.

In order to aid people who don't have an environment in which
they can run xmkmf I have created this tar package which includes
the Makefile, ready for the 'make' command to be run.

If in doubt, look through Makefile and see if you wish to change
anything, before running 'make'.

I hope this is of use to someone.

Aaron Sloman
A.Sloman@cs.bham.ac.uk
http://www.cs.bham.ac.uk/~axs/
